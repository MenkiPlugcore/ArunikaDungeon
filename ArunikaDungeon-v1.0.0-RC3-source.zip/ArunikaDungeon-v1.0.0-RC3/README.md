# ArunikaDungeon 1.0.0-RC3 — Guardian Awakening

**Source only — official build blocked; runtime stabilization preparation, not a verified JAR or production release.** Based on RC2 source. No new gameplay features. Includes targeted startup/shutdown hardening, the verified build pipeline and an isolated Paper smoke-test utility.

See [RC3 staging & build guide](docs/RC3-STAGING.md), [actual test logs](docs/rc3-tests/), and [original RC1 installation and rollback guide](docs/RC1-INSTALLATION.md) (use RC3 artifact paths). Old version documents are historical. Do not replace production plugins or Waystones.

Run `bash tools/build-verified.sh` or `powershell -ExecutionPolicy Bypass -File tools/build-verified.ps1` with Java 21 and Maven 3.9.x and official repository access. Only after successful build, use the artifact in `target/verified/` for staging. Run `python tools/smoke-paper.py --help` for the new local runtime test. No Paper runtime execution completed here.
