package site.cadera.arunika.dungeon.exchange;
import java.nio.file.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.security.*;
/** Run only when old Exchange not loaded. Copies WAL into disposable work dir; never connects to old DB. */
public final class ExchangeMigration {
 private static final List<String> FILES=List.of("config.yml","rewards.yml","exchange.db","exchange.db-wal","exchange.db-shm");
 private static Map<String,String> hashes(Path dir)throws Exception{var m=new LinkedHashMap<String,String>();for(String name:FILES){Path f=dir.resolve(name);if(Files.exists(f,LinkOption.NOFOLLOW_LINKS)){if(!Files.isRegularFile(f,LinkOption.NOFOLLOW_LINKS))throw new IOException("Unsafe legacy file "+name);try(var in=Files.newInputStream(f)){var md=MessageDigest.getInstance("SHA-256");byte[] buf=new byte[65536];for(int n;(n=in.read(buf))>=0;)md.update(buf,0,n);m.put(name,HexFormat.of().formatHex(md.digest()));}}}return m;}
 public static boolean importOnce(Path source,Path target)throws Exception{
  if(Files.exists(target,LinkOption.NOFOLLOW_LINKS)){if(Files.isSymbolicLink(target)||!Files.isRegularFile(target.resolve("migration-complete.txt"))||!Files.isRegularFile(target.resolve("exchange.db"))||!Files.isRegularFile(target.resolve("rewards.yml"))||!Files.isRegularFile(target.resolve("config.yml")))throw new IOException("Incomplete existing Exchange; refused overwrite");return false;}
  if(!Files.isDirectory(source,LinkOption.NOFOLLOW_LINKS))throw new IOException("Legacy Exchange folder missing");var before=hashes(source);if(!before.keySet().containsAll(List.of("config.yml","rewards.yml","exchange.db")))throw new IOException("Incomplete legacy Exchange");Files.createDirectories(target.getParent());Path temp=Files.createTempDirectory(target.getParent(),".exchange-import-");
  try{Path raw=Files.createDirectory(temp.resolve("legacy-original"));for(String f:before.keySet())Files.copy(source.resolve(f),raw.resolve(f));if(!before.equals(hashes(raw))||!before.equals(hashes(source)))throw new IOException("Legacy changed during import");Path work=Files.createDirectory(temp.resolve("work"));for(String f:List.of("exchange.db","exchange.db-wal"))if(Files.exists(raw.resolve(f)))Files.copy(raw.resolve(f),work.resolve(f));Files.copy(raw.resolve("config.yml"),temp.resolve("config.yml"));Files.copy(raw.resolve("rewards.yml"),temp.resolve("rewards.yml"));Class.forName("org.sqlite.JDBC");try(var c=DriverManager.getConnection("jdbc:sqlite:"+work.resolve("exchange.db"));var s=c.createStatement()){try(var r=s.executeQuery("PRAGMA integrity_check")){if(!r.next()||!r.getString(1).equals("ok")||r.next())throw new SQLException("Legacy integrity failure");}s.execute("VACUUM INTO '"+temp.resolve("exchange.db").toString().replace("'","''")+"'");}
   try(var c=DriverManager.getConnection("jdbc:sqlite:"+temp.resolve("exchange.db"));var s=c.createStatement()){for(String t:List.of("transactions","purchases","reward_stock"))try(var r=s.executeQuery("SELECT COUNT(*) FROM "+t)){if(!r.next())throw new SQLException("Missing table "+t);}}
   if(!before.equals(hashes(source)))throw new IOException("Legacy changed during migration");delete(work);Files.writeString(temp.resolve("migration-complete.txt"),"v0.7.0\n"+before+"\n");Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE);return true;
  }finally{if(Files.exists(temp))delete(temp);}
 }
 private static void delete(Path p)throws IOException{try(var walk=Files.walk(p)){for(Path f:walk.sorted(Comparator.reverseOrder()).toList())Files.delete(f);}}
}
