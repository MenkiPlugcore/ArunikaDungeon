from pathlib import Path
import re
root=Path(__file__).resolve().parent/'ArunikaDungeon-1.0.1'
g=root/'src/main/java/site/cadera/arunika/dungeon/paper/PaperGateway.java'
s=g.read_text()
assert s.count('new WaystoneBridge')==3, 'unexpected gateway implementation'
s=s.replace('WaystoneBridge','DungeonOnlyBridge')
s=s.replace('Bukkit.getPluginManager().getPlugin("CdrWaystone")','Bukkit.getPluginManager().getPlugin("ArunikaDungeonWaystone")')
s=s.replace('"CdrWaystone missing"','"ArunikaDungeonWaystone missing"')
s=s.replace('"CdrWaystone not enabled"','"ArunikaDungeonWaystone not enabled"')
s=s.replace('"Hub must be a permanent admin Waystone, hidden from network and not legacy-bound"','"HUB must be a dedicated DungeonWaystone node"')
s=s.replace('if(!bridge.dedicated(hubStone))throw','if(!bridge.isHub(hubStone))throw')
s=s.replace('if(!bridge.dedicated(stone)||!plugin.gatewayStoneInArena(e.getValue(),bridge.location(stone)))','if(!bridge.isReturn(stone,e.getValue())||!plugin.gatewayStoneInArena(e.getValue(),bridge.location(stone)))')
s=s.replace('if(!bridge.dedicated(stone))continue;','if(!(cfg.hubId().equals(id)?bridge.isHub(stone):bridge.isReturn(stone,cfg.returns().get(id))))continue;')
s=s.replace('if(bridge.dedicated(stone))route(p,stone);','if(bridge.dedicated(stone))route(p,stone);')
s=s.replace('"Waystone public ABI: OK | "','"DungeonWaystone API: OK | "')
s=s.replace('Bukkit.getPluginManager().getPlugin("CdrWaystoneBedrock")','Bukkit.getPluginManager().getPlugin("ArunikaDungeonWaystoneBedrock")')
s=s.replace('"Waystone UUID: "+b.id(s)+" | permanent admin: "+b.official(s)+" | hidden and unbound: "+b.dedicated(s)','"DungeonWaystone UUID: "+b.id(s)+" | dedicated: "+b.dedicated(s)+" | HUB: "+b.isHub(s)')
s=s.replace('b.dedicated(s)&&plugin.gatewayStoneInArena(e.getValue(),b.location(s))','b.isReturn(s,e.getValue())&&plugin.gatewayStoneInArena(e.getValue(),b.location(s))')
s=s.replace('"Hub dedicated="+b.dedicated(s)','"Hub dedicated="+b.isHub(s)')
# Fast fail closed: a RETURN role must match the configured target even if the ID was stolen.
s=s.replace('if(!plugin.gatewayUsable()||!p.hasPermission("arunika.dungeon.gateway.test")||!bridge.allowed(p,stone,cfg.radius(),cfg.hubId().equals(id)))', 'if(!plugin.gatewayUsable()||!p.hasPermission("arunika.dungeon.gateway.test")||!(cfg.hubId().equals(id)?bridge.isHub(stone):bridge.isReturn(stone,cfg.returns().get(id)))||!bridge.allowed(p,stone,cfg.radius(),cfg.hubId().equals(id)))')
assert 'CdrWaystone' not in s
assert 'bridge.isHub' in s and 'bridge.isReturn' in s
# When validation checks the menu after registration changes, deny mismatched role/arena.
s=s.replace('&&bound(m.stone)&&(m.screen==Screen.RETURN?', '&&bound(m.stone)&&(m.screen==Screen.RETURN?bridge.isReturn(bridge.stone(m.stone),cfg.returns().get(m.stone))&&')
s=s.replace(':atHub(p));}', ':bridge.isHub(bridge.stone(cfg.hubId()))&&atHub(p));}')
g.write_text(s)
# update runtime labels, source manifests, and dependency list carefully
plugin=root/'src/main/resources/plugin.yml'
p=plugin.read_text().replace("version: '1.0.0-RC6'","version: '1.0.1'")
p=p.replace('CdrWaystone,', 'ArunikaDungeonWaystone, ArunikaDungeonWaystoneBedrock,')
p=p.replace('opt-in Waystone gateway staging.','dungeon-only Waystone gateway staging.')
plugin.write_text(p)
pom=root/'pom.xml'
p=pom.read_text().replace('<version>1.0.0-RC6</version>','<version>1.0.1</version>').replace('<finalName>ArunikaDungeon-1.0.0-RC6</finalName>','<finalName>ArunikaDungeon-1.0.1</finalName>')
pom.write_text(p)
# Update template without replacing old user data: default remains locked.
f=root/'src/main/resources/templates/integrations/waystone.yml'
s=f.read_text().replace('No changes to CdrWaystone\'s own files.', 'Binds nodes from ArunikaDungeonWaystone. Existing survival waystones untouched.')
s=s.replace('# Registered official Waystone UUID:', '# Dungeon-only RETURN node UUID:')
f.write_text(s)
# Release/staging log labels are a cosmetic bug in prior source; fix without touching other artifacts.
pl=root/'src/main/java/site/cadera/arunika/dungeon/paper/ArunikaDungeonPlugin.java'
s=pl.read_text().replace('RC6 staging; public entry disabled.', 'v1.0.1 staging; entry requires validated dungeon-only anchors.').replace('[ArunikaDungeon 1.0.0-RC6]', '[ArunikaDungeon 1.0.1]')
pl.write_text(s)
print('Patched ArunikaDungeon 1.0.1 (dungeon-only bridge, role safety, metadata).')
