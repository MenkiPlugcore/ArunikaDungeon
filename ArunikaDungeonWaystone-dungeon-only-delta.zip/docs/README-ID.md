# Arunika Dungeon Waystone — Dedicated Plugin (Staging v0.1.0)

## Tujuan
Dua jenis node saja: **HUB** (membuka GUI dungeon) dan **RETURN** (meminta keluar dari arena). Tidak ada transportasi survival, network umum, crafting, ekonomi, atau teleportasi milik plugin Waystone baru. Semua mekanisme bermain, ticket, party, boss, loot, GUI, dan perpindahan arena tetap dikendalikan oleh **ArunikaDungeon 1.0.1**.

## Arsitektur
- `ArunikaDungeonWaystone-0.1.0.jar`: registrasi Lodestone khusus dungeon, UUID persistent, proteksi blok, pengecekan akses, command admin, ekspor binding.
- `ArunikaDungeonWaystoneBedrock-0.1.0.jar`: pendamping opsional. Native Lodestone bisa diklik pemain Bedrock tanpa model/hitbox custom. Particle hint opsional, mati secara default.
- `ArunikaDungeon-1.0.1.jar`: GUI dungeon dan segala aturan gameplay. Bridge ke Waystone baru tidak bergantung pada `CdrWaystone`.

**Tidak ada migrasi otomatis dari CdrWaystone.** Data pemain dan Waystone survival lama tidak disentuh. Jangan mendaftarkan Lodestone yang sama di dua plugin.

## Instalasi staging
1. **Backup** folder `plugins/ArunikaDungeon/`, Waystone lama dan dunia.
2. Stop server Paper 1.21.11 / Java 21.
3. Pasang ketiga JAR baru ke `plugins/`, pastikan hanya satu JAR per nama plugin. Plugin CdrWaystone survival **boleh dipertahankan**, asalkan anchor dungeon baru bukan miliknya.
4. Restart; pastikan `/adw status` menunjukkan registry siap dan jumlah node benar.
5. Tempatkan **Lodestone vanilla yang belum didaftarkan CdrWaystone** di Hub dan tiap arena (staff OP menggunakan `/setblock` atau WorldEdit tanpa mendaftarkan sebagai Waystone survival; `/adw` akan menolak collision).
6. Arahkan pandangan ke Lodestone Hub, ketik `/adw hub`.
7. Untuk setiap arena arahkan ke Lodestone return, `/adw return <floor-id> <arena-id>`.
8. Jalankan `/adw list` dan `/adw export`, kemudian periksa `plugins/ArunikaDungeonWaystone/waystone-export.yml`. **Ekspor tidak menimpa konfigurasi ArunikaDungeon**.
9. Salin binding yang benar ke `plugins/ArunikaDungeon/integrations/waystone.yml`. Pastikan `hub` sama dengan titik keluar `exit` setiap arena di konfigurasi ArunikaDungeon. Ubah `enabled: true` hanya sesudah semua arena tervalidasi.
10. Jalankan `/adg reload all`, `/adg gateway check`, `/adg diagnostics` dan uji klien Java & Bedrock di server staging.

### Perintah
- `/adw status` / `/adw check`: status registry, anchor rusak dan benturan legacy.
- `/adw hub`: daftarkan Lodestone yang sedang ditatap sebagai satu-satunya HUB.
- `/adw return <floor> <arena>`: daftarkan Lodestone Return untuk satu arena.
- `/adw inspect`: identitas anchor yang ditatap.
- `/adw list`: daftar semua binding.
- `/adw remove`: lepas registrasi anchor yang ditatap (tidak menghapus blok).
- `/adw export`: hasilkan konfigurasi binding untuk ditinjau admin.

## Backward compatibility
- `CdrWaystone` lama tidak diganti oleh plugin ini. Biarkan `plugins/CdrWaystone/` tetap aman.
- ArunikaDungeon 1.0.0 Phase 7 memakai bridge lama; **jangan campur** dengan versi baru tanpa memeriksa `/adg gateway check`.
- Simpan backup untuk rollback ke ArunikaDungeon 1.0.0 Phase 7 dan versi Waystone lama. Jika rollback, kembalikan konfigurasi Waystone lama juga.

## Keamanan dan keterbatasan tes
- Registrasi terkunci jika registry YAML tidak valid; tidak direset otomatis.
- Registrasi HUB/RETURN terjadi hanya dari admin OP melalui command.
- Tidak memindahkan pemain atau mengurangi ticket. Setiap klik dikelola oleh ArunikaDungeon.
- Node memerlukan world/chunk dan blok Lodestone yang sesuai serta tidak boleh overlap Waystone survival.
- Tes CI menguji kompilasi terhadap Paper API asli, unit test Node dan regresi core Dungeon. Tes client Bedrock HP serta uji runtime campuran **harus dilakukan di staging**. Jangan menyebut build ini production-ready tanpa pengujian tersebut.
