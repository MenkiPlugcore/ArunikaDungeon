import dev.arunika.dungeonwaystone.Node;
import java.util.UUID;
public final class NodeTest {
  private static int checks;
  private static void ok(boolean condition){checks++;if(!condition)throw new AssertionError("check "+checks);}
  private static void reject(Runnable r){checks++;try{r.run();throw new AssertionError("accepted invalid record");}catch(IllegalArgumentException expected){}}
  public static void main(String[] args){
    UUID id=UUID.randomUUID(),world=UUID.randomUUID();
    Node hub=new Node(id,Node.Role.HUB,"",world,"hub",1,2,3);
    ok(hub.id().equals(id));ok(hub.role()==Node.Role.HUB);ok(hub.target().equals(""));
    Node ret=new Node(UUID.randomUUID(),Node.Role.RETURN,"mega_warden/main",world,"dungeon",1,2,3);
    ok(ret.role()==Node.Role.RETURN);ok(ret.target().equals("mega_warden/main"));
    reject(()->new Node(null,Node.Role.HUB,"",world,"hub",1,2,3));
    reject(()->new Node(id,null,"",world,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.HUB,"boss/arena",world,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.RETURN,"",world,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.RETURN,"../bad",world,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.RETURN,"Boss/arena",world,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.HUB,"",null,"hub",1,2,3));
    reject(()->new Node(id,Node.Role.HUB,"",world,"",1,2,3));
    System.out.println("PASS Node constructor and role validation: "+checks+" assertions");
  }
}
