package dev.arunika.dungeonwaystone.bedrock;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.UUID;

/** Optional hint-only companion. Does not spawn entities, intercept clicks, own GUI, or teleport. */
public final class DungeonWaystoneBedrockPlugin extends JavaPlugin {
    private BukkitTask task;
    private boolean floodgate;
    private Object floodgateApi;
    private Method isFloodgate;
    private Object core;
    private Method getNodes;
    private Method getLocation;
    @Override public void onEnable(){
        saveDefaultConfig();
        Plugin p=Bukkit.getPluginManager().getPlugin("ArunikaDungeonWaystone");
        if(p==null||!p.isEnabled()){getLogger().severe("DungeonWaystone core unavailable; no visuals started.");return;}
        core=p;
        try{
            getNodes=p.getClass().getMethod("getNodes");
            Class<?> node=Class.forName("dev.arunika.dungeonwaystone.Node",true,p.getClass().getClassLoader());
            getLocation=p.getClass().getMethod("location",node);
        }catch(Exception ex){getLogger().severe("Incompatible core API: "+ex.getMessage());return;}
        Plugin f=Bukkit.getPluginManager().getPlugin("floodgate");
        if(f!=null&&f.isEnabled())try{
            Class<?> api=Class.forName("org.geysermc.floodgate.api.FloodgateApi",false,f.getClass().getClassLoader());
            floodgateApi=api.getMethod("getInstance").invoke(null);isFloodgate=api.getMethod("isFloodgatePlayer",UUID.class);
            floodgate=floodgateApi!=null;
        }catch(Exception | LinkageError ex){getLogger().warning("Floodgate bridge not ready; native block interaction remains available.");}
        if(getConfig().getBoolean("visual-hint.enabled",false)) {
            long interval=Math.max(20,Math.min(200,getConfig().getLong("visual-hint.interval-ticks",40)));
            task=Bukkit.getScheduler().runTaskTimer(this,this::hints,interval,interval);
        }
        getLogger().info("Bedrock native-Lodestone mode enabled. Hints="+(task!=null)+", Floodgate="+floodgate+"; no GUI or hitbox modifications.");
    }
    @Override public void onDisable(){if(task!=null){task.cancel();task=null;}floodgateApi=null;isFloodgate=null;core=null;getNodes=null;getLocation=null;}
    private boolean bedrock(Player p){if(!floodgate||floodgateApi==null||isFloodgate==null)return false;try{return Boolean.TRUE.equals(isFloodgate.invoke(floodgateApi,p.getUniqueId()));}catch(Exception|LinkageError ex){return false;}}
    private void hints(){
        if(core==null||!((Plugin)core).isEnabled()||getNodes==null||getLocation==null)return;
        try{
            Object response=getNodes.invoke(core);if(!(response instanceof Collection<?> nodes))return;
            double radius=Math.max(2,Math.min(16,getConfig().getDouble("visual-hint.radius",8)));
            int limit=Math.max(1,Math.min(8,getConfig().getInt("visual-hint.max-particles-per-player",4)));
            for(Player p:Bukkit.getOnlinePlayers()){
                if(!bedrock(p)||p.isDead())continue;
                int shown=0;
                for(Object node:nodes){
                    if(shown>=limit)break;
                    Location loc=(Location)getLocation.invoke(core,node);
                    if(loc==null||loc.getWorld()!=p.getWorld()||p.getLocation().distanceSquared(loc)>radius*radius)continue;
                    if(!loc.getWorld().isChunkLoaded(loc.getBlockX()>>4,loc.getBlockZ()>>4))continue;
                    p.spawnParticle(Particle.ENCHANT,loc.clone().add(.5,1.15,.5),2,.12,.12,.12,0);
                    shown++;
                }
            }
        }catch(Exception|LinkageError ex){getLogger().warning("Disabling optional hint task due to API error: "+ex.getMessage());if(task!=null){task.cancel();task=null;}}
    }
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){sender.sendMessage("[DungeonWaystoneBedrock] hints="+(task!=null)+" floodgate="+floodgate+" native anchor=LODESTONE");return true;}
}
