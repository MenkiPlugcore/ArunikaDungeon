package site.cadera.arunika.dungeon.paper;

import java.util.*;
import java.util.function.Consumer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import site.cadera.arunika.dungeon.battle.ArenaAccessPolicy;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.plugin.Plugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import site.cadera.arunika.dungeon.config.SmartConfiguration.Gateway;
import site.cadera.arunika.dungeon.core.DungeonGatewayApi.*;

/** Native inventory UI works via normal Geyser inventory translation; no proprietary form dependency. */
final class PaperGateway implements Listener {
 private final ArunikaDungeonPlugin plugin; private final Gateway cfg; private final WaystoneBridge bridge;
 private final Map<UUID,Menu> menus=new HashMap<>();
 private final GatewayRateLimiter airLimiter=new GatewayRateLimiter(350_000_000L,1024);
 private final List<UUID> boundStones;
 private Plugin floodgateProvider;
 private java.lang.reflect.Method floodgateMethod;
 private Object floodgateApi;
 private int refreshCursor;
 private static final int PAGE=GatewayMenuStyle.PAGE_SIZE;
 private record Status(List<SharedFloorStatus> shared,List<PrivatePartyStatus> parties,List<site.cadera.arunika.dungeon.core.SessionRegistry.Session> sessions,List<site.cadera.arunika.dungeon.battle.BattleEngine.View> battles){}
 private Status cached;
 private Status status(){return cached!=null?cached:new Status(plugin.sharedStatus(),plugin.privateStatus(),plugin.gatewaySessions(),plugin.gatewayBattles());}
 private enum Screen{HOME,FLOORS,SHARED,PRIVATE_DETAIL,PARTY,INVITE,RETURN}
 private static final class Menu implements InventoryHolder {
  final UUID owner,stone; final Screen screen; final boolean priv; final String floor; final int page;
  boolean clickPending;final Map<Integer,Consumer<Player>> actions=new HashMap<>(); final BitSet written=new BitSet(54); final Inventory inventory;
  Menu(Player p,UUID stone,Screen screen,boolean priv,String floor,int page){owner=p.getUniqueId();this.stone=stone;this.screen=screen;this.priv=priv;this.floor=floor;this.page=page;inventory=Bukkit.createInventory(this,54,Component.text("ARUNIKA | "+switch(screen){case HOME->"Dungeon Hub";case FLOORS->priv?"Private Floors":"Shared Floors";case SHARED->"Shared Participants";case PRIVATE_DETAIL->"Private Participants";case PARTY->"Private Party";case INVITE->"Invite Players";case RETURN->"Return to Hub";}).color(NamedTextColor.LIGHT_PURPLE));}
  @Override public Inventory getInventory(){return inventory;}
 }
 PaperGateway(ArunikaDungeonPlugin plugin,Gateway cfg)throws ReflectiveOperationException{this.plugin=plugin;this.cfg=cfg;Plugin ws=Bukkit.getPluginManager().getPlugin("CdrWaystone");if(ws==null||!ws.isEnabled())throw new IllegalStateException("CdrWaystone missing");bridge=new WaystoneBridge(ws);Object hubStone=bridge.stone(cfg.hubId());if(!bridge.dedicated(hubStone))throw new IllegalStateException("Hub must be a permanent admin Waystone, hidden from network and not legacy-bound");var anchor=bridge.location(hubStone);if(anchor==null||anchor.getWorld()==null||!ArenaAccessPolicy.near(PaperBattlePort.point(anchor.clone().add(.5,.5,.5)),cfg.hub(),cfg.radius()))throw new IllegalStateException("Hub exit must be in the same world and within interaction radius of its registered Waystone");
 if(cfg.returns().containsKey(cfg.hubId()))throw new IllegalStateException("Hub UUID cannot be reused as a Return Waystone");
 List<UUID> ids=new ArrayList<>(1+cfg.returns().size());ids.add(cfg.hubId());ids.addAll(cfg.returns().keySet());boundStones=List.copyOf(ids);
 for(var e:cfg.returns().entrySet()){Object stone=bridge.stone(e.getKey());if(!bridge.dedicated(stone)||!plugin.gatewayStoneInArena(e.getValue(),bridge.location(stone)))throw new IllegalStateException("Invalid return stone: "+e.getKey());}}
 boolean atHub(Player p){try{if(!p.hasPermission("arunika.dungeon.gateway.test")||!bridge.allowed(p,bridge.stone(cfg.hubId()),cfg.radius(),true))return false;var hub=PaperBattlePort.location(cfg.hub());return p.getWorld().equals(hub.getWorld())&&p.getLocation().distanceSquared(hub)<=cfg.radius()*cfg.radius();}catch(RuntimeException|LinkageError e){return false;}}
 private boolean bound(UUID id){return cfg.hubId().equals(id)||cfg.returns().containsKey(id);}
 @EventHandler(priority=EventPriority.NORMAL,ignoreCancelled=true) public void block(PlayerInteractEvent e){if(e.getAction()!=Action.RIGHT_CLICK_BLOCK||e.getHand()!=EquipmentSlot.HAND||e.getClickedBlock()==null||!bridge.available())return;try{Object stone=bridge.stone(e.getClickedBlock());if(stone==null||!bound(bridge.id(stone)))return;e.setCancelled(true);route(e.getPlayer(),stone);}catch(RuntimeException|LinkageError err){e.getPlayer().sendMessage("Dungeon Waystone unavailable.");}}
 @EventHandler(priority=EventPriority.NORMAL,ignoreCancelled=true) public void plainEntity(PlayerInteractEntityEvent e){if(!(e instanceof PlayerInteractAtEntityEvent))entityClick(e);}
 @EventHandler(priority=EventPriority.NORMAL,ignoreCancelled=true) public void entity(PlayerInteractAtEntityEvent e){entityClick(e);}
 private void entityClick(PlayerInteractEntityEvent e){if(e.getHand()!=EquipmentSlot.HAND||!bridge.available())return;try{Object stone=bridge.stone(e.getRightClicked());if(stone==null||!bound(bridge.id(stone)))return;e.setCancelled(true);route(e.getPlayer(),stone);}catch(RuntimeException|LinkageError err){e.getPlayer().sendMessage("Dungeon Waystone unavailable.");}}
 /** Bedrock visual proxy is a marker ArmorStand (no normal hitbox). Only deliberate
  *  right-click-air gestures with empty hand may open a *registered* Dungeon Waystone.
  *  All real permission, anchor, session, and cooldown checks remain in route(). */
 @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=false)
 public void bedrockAir(PlayerInteractEvent e){
  if(e.getAction()!=Action.RIGHT_CLICK_AIR||e.getHand()!=EquipmentSlot.HAND)return;
  Player p=e.getPlayer();
  if(!plugin.gatewayUsable()||!bridge.available()||!p.isOnline()||p.isDead())return;
  if(!p.getInventory().getItemInMainHand().getType().isAir())return;
  if(p.getOpenInventory().getTopInventory().getType()!=InventoryType.CRAFTING)return;
  if(!isFloodgatePlayer(p))return;
  long now=System.nanoTime();if(!airLimiter.ready(p.getUniqueId(),now))return;
  Location eye=p.getEyeLocation();var dir=eye.getDirection().normalize();
  GatewayAim.Vec epos=new GatewayAim.Vec(eye.getX(),eye.getY(),eye.getZ());
  GatewayAim.Vec aim=new GatewayAim.Vec(dir.getX(),dir.getY(),dir.getZ());
  // UUID bindings are immutable for this gateway instance; avoid allocating on every tap.
  UUID chosen=null;double score=Double.POSITIVE_INFINITY;boolean ambiguous=false;
  for(UUID id:boundStones){
   if(id==null)continue;
   try{
    Object stone=bridge.stone(id);if(!bridge.dedicated(stone))continue;
    Location l=bridge.location(stone);if(l==null||l.getWorld()==null||!l.getWorld().equals(eye.getWorld()))continue;
    if(p.getLocation().distanceSquared(l.clone().add(.5,.5,.5))>cfg.radius()*cfg.radius())continue;
    GatewayAim.Hit hit=GatewayAim.match(epos,aim,new GatewayAim.Vec(l.getBlockX(),l.getBlockY(),l.getBlockZ()),Math.min(cfg.radius(),6.0),0.70);
    if(hit==null)continue;
    Block first=p.getTargetBlockExact(Math.min(8,(int)Math.ceil(hit.distance()+1.0)));
    if(first!=null){Object seen=bridge.stone(first);if(seen==null||!id.equals(bridge.id(seen)))continue;}
    if(hit.deviationSquared()<score-0.02){score=hit.deviationSquared();chosen=id;ambiguous=false;}
    else if(Math.abs(hit.deviationSquared()-score)<=0.02)ambiguous=true;
   }catch(RuntimeException|LinkageError ignored){ /* fail closed; do not hijack normal gameplay */ }
  }
  if(chosen==null||ambiguous)return;
  airLimiter.commit(p.getUniqueId(),now);UUID finalId=chosen;
  Bukkit.getScheduler().runTask(plugin,()->{
   if(!p.isOnline()||!plugin.gatewayUsable())return;
   try{Object stone=bridge.stone(finalId);if(bridge.dedicated(stone))route(p,stone);}
   catch(RuntimeException|LinkageError err){p.sendMessage("Dungeon Waystone temporarily unavailable.");}
  });
 }
 /** Cache the Floodgate ABI per enabled plugin instance, not per right-click.
  * Fail closed when absent, changed, unloaded or throwing. */
 private boolean isFloodgatePlayer(Player p){
  Plugin f=Bukkit.getPluginManager().getPlugin("floodgate");
  if(f==null||!f.isEnabled()){
   floodgateProvider=null;floodgateMethod=null;floodgateApi=null;return false;
  }
  if(floodgateProvider!=f){
   floodgateProvider=f;floodgateMethod=null;floodgateApi=null;
   try{
    Class<?> c=Class.forName("org.geysermc.floodgate.api.FloodgateApi",false,f.getClass().getClassLoader());
    Object api=c.getMethod("getInstance").invoke(null);
    java.lang.reflect.Method method=c.getMethod("isFloodgatePlayer",UUID.class);
    floodgateApi=api;floodgateMethod=method;
   }catch(ReflectiveOperationException|LinkageError ex){return false;}
  }
  if(floodgateMethod==null||floodgateApi==null)return false;
  try{return Boolean.TRUE.equals(floodgateMethod.invoke(floodgateApi,p.getUniqueId()));}
  catch(ReflectiveOperationException|LinkageError ex){
   floodgateMethod=null;floodgateApi=null;return false;
  }
 }

 void openTarget(Player p){try{Block block=p.getTargetBlockExact((int)Math.ceil(cfg.radius()));Object stone=block==null?null:bridge.stone(block);if(stone==null||!bound(bridge.id(stone)))throw new IllegalStateException("Look at the bound Waystone anchor");route(p,stone);}catch(RuntimeException|LinkageError e){p.sendMessage("Gateway unavailable: "+e.getMessage());}}
 private void route(Player p,Object stone){UUID id=bridge.id(stone);Menu existing=menus.get(p.getUniqueId());if(existing!=null&&existing.stone.equals(id)&&p.getOpenInventory().getTopInventory()==existing.inventory&&valid(p,existing))return;if(!plugin.gatewayUsable()||!p.hasPermission("arunika.dungeon.gateway.test")||!bridge.allowed(p,stone,cfg.radius(),cfg.hubId().equals(id))){p.sendMessage("Dungeon gateway unavailable or access denied.");return;}if(cfg.hubId().equals(id)){if(!atHub(p)){p.sendMessage("Stand at the Dungeon Hub.");return;}open(p,id,Screen.HOME,false,"",0);}else if(plugin.gatewayReturnEligible(p,cfg.returns().get(id),bridge.location(stone)))open(p,id,Screen.RETURN,false,cfg.returns().get(id),0);else p.sendMessage("Return Waystone requires your own active arena session.");}
 static void check(ArunikaDungeonPlugin plugin,CommandSender sender){try{Plugin ws=Bukkit.getPluginManager().getPlugin("CdrWaystone");if(ws==null||!ws.isEnabled())throw new IllegalStateException("CdrWaystone not enabled");WaystoneBridge b=new WaystoneBridge(ws);sender.sendMessage("Waystone public ABI: OK | "+ws.getDescription().getVersion());Plugin bed=Bukkit.getPluginManager().getPlugin("CdrWaystoneBedrock");sender.sendMessage("Bedrock renderer: "+(bed==null?"missing":bed.getDescription().getVersion()+" / enabled="+bed.isEnabled())+" | native anchor + target fallback; proxy clicks require client test");var cfg=plugin.adminSnapshot().gateway();sender.sendMessage("Gateway config enabled="+cfg.enabled()+" | hub UUID="+cfg.hubId()+" | return bindings="+cfg.returns().size());if(cfg.hubId()!=null){Object s=b.stone(cfg.hubId());sender.sendMessage("Hub dedicated="+b.dedicated(s)+(s==null?"":" | anchor="+b.location(s)));}for(var e:cfg.returns().entrySet()){Object s=b.stone(e.getKey());sender.sendMessage(e.getValue()+": "+e.getKey()+" | valid="+(b.dedicated(s)&&plugin.gatewayStoneInArena(e.getValue(),b.location(s))));}}catch(Exception|LinkageError e){sender.sendMessage("Waystone diagnostic failed: "+e);}}
 static void inspect(ArunikaDungeonPlugin plugin,Player p){try{Plugin ws=Bukkit.getPluginManager().getPlugin("CdrWaystone");if(ws==null||!ws.isEnabled())throw new IllegalStateException("CdrWaystone missing");WaystoneBridge b=new WaystoneBridge(ws);Block block=p.getTargetBlockExact(8);Object s=block==null?null:b.stone(block);if(s==null)throw new IllegalStateException("Look at a registered Waystone anchor block");p.sendMessage("Waystone UUID: "+b.id(s)+" | permanent admin: "+b.official(s)+" | hidden and unbound: "+b.dedicated(s)+" | "+b.location(s));}catch(Exception|LinkageError e){p.sendMessage("Waystone inspect: "+e.getMessage());}}
 void close(){HandlerList.unregisterAll(this);for(var m:new ArrayList<>(menus.values())){Player p=Bukkit.getPlayer(m.owner);if(p!=null&&p.getOpenInventory().getTopInventory()==m.inventory)p.closeInventory();}menus.clear();airLimiter.clear();floodgateProvider=null;floodgateMethod=null;floodgateApi=null;refreshCursor=0;cached=null;}
 private boolean valid(Player p,Menu m){try{return plugin.gatewayUsable()&&p.getUniqueId().equals(m.owner)&&p.hasPermission("arunika.dungeon.gateway.test")&&bound(m.stone)&&(m.screen==Screen.RETURN?bridge.allowed(p,bridge.stone(m.stone),cfg.radius(),false)&&plugin.gatewayReturnEligible(p,cfg.returns().get(m.stone),bridge.location(bridge.stone(m.stone))):atHub(p));}catch(RuntimeException|LinkageError e){return false;}}
 private void open(Player p,UUID id,Screen s,boolean priv,String floor,int page){Menu m=new Menu(p,id,s,priv,floor,Math.max(0,page));if(!valid(p,m))return;render(p,m);p.openInventory(m.inventory);menus.put(p.getUniqueId(),m);}
 private void go(Player p,Menu m,Screen s,boolean priv,String floor,int page){open(p,m.stone,s,priv,floor,page);}
 private void button(Menu m,int slot,Material mat,String name,List<String> lore,Consumer<Player> action){
  if(slot<0||slot>=GatewayMenuStyle.MENU_SIZE)throw new IllegalArgumentException("GUI slot out of range: "+slot);
  ItemStack item=new ItemStack(mat);
  var meta=item.getItemMeta();
  meta.displayName(GuiTheme.name(GatewayMenuStyle.compact(name,44),mat));
  meta.lore(GatewayMenuStyle.lore(lore).stream().map(GuiTheme::lore).toList());
  item.setItemMeta(meta);
  m.written.set(slot);
  if(!item.equals(m.inventory.getItem(slot)))m.inventory.setItem(slot,item);
  if(action!=null)m.actions.put(slot,action);
}
 private void button(Menu m,int slot,Material mat,String name,Consumer<Player> action){button(m,slot,mat,name,List.of(),action);}
 private String name(UUID id){Player p=Bukkit.getPlayer(id);return p==null?"Offline #"+id.toString().substring(0,8):p.getName();}
 private List<String> names(Collection<UUID> ids){List<String> n=ids.stream().limit(5).map(this::name).toList();var out=new ArrayList<>(n);if(ids.size()>5)out.add("+"+(ids.size()-5)+" more");return out;}
 private Optional<PrivatePartyStatus> party(Player p){return status().parties().stream().filter(v->v.members().contains(p.getUniqueId())).findFirst();}
 private void pageButtons(Menu m,int size){
  int last=GatewayMenuStyle.pages(size)-1;
  button(m,46,Material.PAPER,GatewayMenuStyle.pageLabel(m.page,size),List.of("Entries: "+size),null);
  if(m.page>0)button(m,45,Material.ARROW,"Previous page",p->go(p,m,m.screen,m.priv,m.floor,Math.min(m.page-1,last)));
  if(m.page<last)button(m,53,Material.ARROW,"Next page",p->go(p,m,m.screen,m.priv,m.floor,m.page+1));
  if(m.page>last)button(m,22,Material.PAPER,"List changed",List.of("Choose Previous page to see items"),null);
}
 private void chrome(Player p,Menu m){
  if(m.screen==Screen.HOME||m.screen==Screen.RETURN){
   for(int slot=0;slot<9;slot++)if(!m.written.get(slot))button(m,slot,Material.PURPLE_STAINED_GLASS_PANE," ",null);
  }
  if(!m.written.get(36))button(m,36,Material.NETHER_STAR,"ARUNIKA DUNGEON",List.of("Gateway: "+switch(m.screen){
   case HOME->"Choose dungeon mode";case FLOORS->m.priv?"Private floors":"Shared floors";
   case SHARED->"Shared queue";case PRIVATE_DETAIL->"Private room";case PARTY->"Party management";
   case INVITE->"Invite online players";case RETURN->"Return Waystone";}),null);
  if(!m.written.get(44))button(m,44,Material.AMETHYST_SHARD,"Dungeon Gateway",List.of("Native inventory interface","No new GUI textures required"),null);
  if(!m.written.get(47))button(m,47,Material.BOOK,"Quick guide",switch(m.screen){
   case HOME->List.of("Shared: free entry","Private: one ticket per party");
   case FLOORS->List.of("Choose an available floor","Gray entries are unavailable");
   case SHARED->List.of("Join queue to enter Shared","Leave queue before battle starts");
   case PRIVATE_DETAIL->List.of("Create a party for this floor","Leader uses the Universal Ticket");
   case PARTY->List.of("Invite players, then Ready","Leader can start a session");
   case INVITE->List.of("Select an online player","Only eligible players are shown");
   case RETURN->List.of("Return leaves your battle","No refund for voluntary exit");},null);
  if(m.screen!=Screen.RETURN&&!m.written.get(51))button(m,51,Material.CLOCK,"Refresh information",List.of("Update queue and party information"),q->go(q,m,m.screen,m.priv,m.floor,m.page));
  for(int slot=36;slot<45;slot++)if(!m.written.get(slot))button(m,slot,Material.BLACK_STAINED_GLASS_PANE," ",null);
  for(int slot=45;slot<54;slot++)if(!m.written.get(slot))button(m,slot,Material.GRAY_STAINED_GLASS_PANE," ",null);
 }
 private void render(Player p,Menu m){m.written.clear();m.actions.clear();switch(m.screen){
  case HOME->{button(m,20,Material.EMERALD,"Shared Dungeon",List.of("Free access","No dungeon participant cap"),q->go(q,m,Screen.FLOORS,false,"",0));button(m,24,Material.AMETHYST_SHARD,"Private Dungeon",List.of("1 Universal Ticket per party","1–5 players"),q->go(q,m,Screen.FLOORS,true,"",0));button(m,38,Material.PLAYER_HEAD,"My Private Party",q->go(q,m,Screen.PARTY,true,"",0));button(m,40,Material.LIME_DYE,"Accept invitation",q->{plugin.gatewayAction(q,true,"accept");go(q,m,Screen.PARTY,true,"",0);});button(m,42,Material.RED_DYE,"Decline invitation",q->{plugin.gatewayAction(q,true,"decline");q.closeInventory();});button(m,49,Material.BARRIER,"Leave Shared queue",q->{plugin.gatewayAction(q,false,"leave");q.closeInventory();});}
  case FLOORS->{var floors=plugin.floors();var statuses=new HashMap<String,SharedFloorStatus>();for(var v:status().shared())statuses.put(v.floor(),v);var parties=status().parties();var battles=status().sessions();if(floors.isEmpty())button(m,22,Material.PAPER,"No dungeons configured",List.of("Ask an admin to finish dungeon setup"),null);int start=m.page*PAGE;for(int i=start;i<Math.min(start+PAGE,floors.size());i++){var f=floors.get(i);boolean available=plugin.gatewayFloor(f.id(),m.priv);List<String> lore=new ArrayList<>();if(!available)lore.add("Unavailable / not configured");else if(m.priv){var groups=parties.stream().filter(v->v.floor().equals(f.id())).toList();lore.add("1 Universal Dungeon Ticket");lore.add("Party waiting: "+groups.size());var runs=battles.stream().filter(v->v.floor().equals(f.id())&&v.mode()==site.cadera.arunika.dungeon.core.SessionRegistry.Mode.PRIVATE).toList();lore.add("Active private sessions: "+runs.size());lore.addAll(names(runs.stream().flatMap(v->v.participants().stream()).distinct().toList()));for(var g:groups.stream().limit(3).toList())lore.add(name(g.leader())+" | "+g.members().size()+" members");}else{var v=statuses.get(f.id());if(v!=null){lore.add(v.state()+" | "+v.seconds()+"s");lore.add("Queue: "+v.queued().size()+" | active: "+v.active().size());lore.addAll(names(v.active().isEmpty()?v.queued():v.active()));}}button(m,i-start,available?(m.priv?Material.AMETHYST_SHARD:Material.EMERALD):Material.GRAY_DYE,"Floor "+f.number()+" - "+f.name(),lore,available?q->{if(m.priv){go(q,m,Screen.PRIVATE_DETAIL,true,f.id(),0);}else go(q,m,Screen.SHARED,false,f.id(),0);}:null);}pageButtons(m,floors.size());button(m,49,Material.COMPASS,"Back",q->go(q,m,Screen.HOME,false,"",0));}
  case SHARED->{var opt=status().shared().stream().filter(v->v.floor().equals(m.floor)).findFirst();if(opt.isPresent()){var v=opt.get();List<UUID> ids=new ArrayList<>(v.active().stream().sorted().toList());for(UUID id:v.queued())if(!v.active().contains(id))ids.add(id);for(int i=m.page*PAGE;i<Math.min((m.page+1)*PAGE,ids.size());i++){UUID id=ids.get(i);button(m,i-m.page*PAGE,Material.PLAYER_HEAD,name(id),List.of(v.living().contains(id)?"Fighting":v.active().contains(id)?"Eliminated / active roster":"Queued"),null);}if(ids.isEmpty())button(m,22,Material.PAPER,"No players in queue",List.of("Be the first to join"),null);pageButtons(m,ids.size());var run=status().sessions().stream().filter(x->x.floor().equals(m.floor)&&x.mode()==site.cadera.arunika.dungeon.core.SessionRegistry.Mode.SHARED).findFirst();List<String> lore=new ArrayList<>(List.of("Queue: "+v.queued().size(),"Active: "+v.active().size()));run.ifPresent(r->status().battles().stream().filter(b->b.id().equals(r.id())).findFirst().ifPresent(b->lore.add(b.phase()+" | Wave "+b.wave()+"/"+b.waveCount())));button(m,40,Material.CLOCK,v.state()+" | "+v.seconds()+"s",lore,null);}button(m,38,Material.LIME_DYE,"Join queue",q->{plugin.gatewayAction(q,false,"join",m.floor);go(q,m,Screen.SHARED,false,m.floor,0);});button(m,42,Material.RED_DYE,"Leave queue",q->{plugin.gatewayAction(q,false,"leave");go(q,m,Screen.SHARED,false,m.floor,0);});button(m,49,Material.COMPASS,"Back",q->go(q,m,Screen.FLOORS,false,"",0));}
  case PRIVATE_DETAIL->{var ids=new LinkedHashMap<UUID,String>();for(var v:status().parties())if(v.floor().equals(m.floor))for(UUID id:v.members().stream().sorted().toList())ids.put(id,v.queued()?"Queued party":"Preparing party");for(var v:status().sessions())if(v.floor().equals(m.floor)&&v.mode()==site.cadera.arunika.dungeon.core.SessionRegistry.Mode.PRIVATE)for(UUID id:v.participants().stream().sorted().toList())ids.put(id,"Active session");var rows=new ArrayList<>(ids.entrySet());for(int i=m.page*PAGE;i<Math.min((m.page+1)*PAGE,rows.size());i++){var row=rows.get(i);button(m,i-m.page*PAGE,Material.PLAYER_HEAD,name(row.getKey()),List.of(row.getValue()),null);}if(rows.isEmpty())button(m,22,Material.PAPER,"No participants yet",List.of("Create a party to get started"),null);pageButtons(m,rows.size());button(m,40,Material.AMETHYST_SHARD,"Create / My Party",List.of("1 ticket per session"),q->{if(party(q).isEmpty())plugin.gatewayAction(q,true,"create",m.floor);go(q,m,Screen.PARTY,true,m.floor,0);});button(m,49,Material.COMPASS,"Back",q->go(q,m,Screen.FLOORS,true,"",0));}
  case PARTY->{var opt=party(p);if(opt.isEmpty()){button(m,22,Material.PAPER,"No private party",q->go(q,m,Screen.FLOORS,true,"",0));}else{var v=opt.get();boolean leader=v.leader().equals(p.getUniqueId());int i=10;for(UUID id:v.members()){button(m,i++,Material.PLAYER_HEAD,name(id),List.of(id.equals(v.leader())?"Leader":"Member",v.ready().contains(id)?"Ready":"Not ready"),null);}button(m,22,Material.PAPER,"Floor: "+v.floor(),List.of(v.queued()?"Waiting for arena":"Preparing party",leader?"Hold a valid ticket before Start":"Leader pays"),null);button(m,28,Material.LIME_DYE,"Ready",q->{plugin.gatewayAction(q,true,"ready");go(q,m,Screen.PARTY,true,v.floor(),0);});button(m,29,Material.YELLOW_DYE,"Not ready",q->{plugin.gatewayAction(q,true,"unready");go(q,m,Screen.PARTY,true,v.floor(),0);});if(leader){button(m,30,Material.PLAYER_HEAD,"Invite player",q->go(q,m,Screen.INVITE,true,v.floor(),0));button(m,32,Material.EMERALD,"Start / Queue",q->{plugin.gatewayAction(q,true,"start");q.closeInventory();});button(m,33,Material.RED_DYE,"Cancel queue",q->{plugin.gatewayAction(q,true,"cancel");go(q,m,Screen.PARTY,true,v.floor(),0);});}button(m,34,Material.BARRIER,"Leave party",q->{plugin.gatewayAction(q,true,"leave");go(q,m,Screen.HOME,false,"",0);});}button(m,49,Material.COMPASS,"Back",q->go(q,m,Screen.HOME,false,"",0));button(m,50,Material.CLOCK,"Refresh",q->go(q,m,Screen.PARTY,true,m.floor,0));}
  case INVITE->{var candidates=Bukkit.getOnlinePlayers().stream().filter(q->!q.equals(p)&&q.hasPermission("arunika.dungeon.gateway.test")&&q.hasPermission("arunika.dungeon.private.test")).sorted(Comparator.comparing(Player::getName)).toList();for(int i=m.page*PAGE;i<Math.min((m.page+1)*PAGE,candidates.size());i++){UUID id=candidates.get(i).getUniqueId();button(m,i-m.page*PAGE,Material.PLAYER_HEAD,candidates.get(i).getName(),q->{Player target=Bukkit.getPlayer(id);if(target!=null)plugin.gatewayAction(q,true,"invite",target.getName());go(q,m,Screen.PARTY,true,m.floor,0);});}if(candidates.isEmpty())button(m,22,Material.PAPER,"No eligible players online",List.of("Try again when friends join"),null);pageButtons(m,candidates.size());button(m,49,Material.COMPASS,"Back",q->go(q,m,Screen.PARTY,true,m.floor,0));}
  case RETURN->{button(m,22,Material.ENDER_PEARL,"Return to Dungeon Hub",List.of("Leave this battle permanently","No refund for voluntary exit"),q->{String[] a=m.floor.split("/",2);if(a.length==2&&plugin.gatewayReturn(q,a[0],a[1],bridge.location(bridge.stone(m.stone))))q.closeInventory();else q.sendMessage("Return refused: not a living participant of this arena, or exit unavailable.");});button(m,31,Material.BARRIER,"Cancel",Player::closeInventory);}
 }chrome(p,m);for(int slot=0;slot<54;slot++)if(!m.written.get(slot)&&m.inventory.getItem(slot)!=null)m.inventory.clear(slot);}
 @EventHandler(priority=EventPriority.HIGHEST) public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu m))return;boolean wasCancelled=e.isCancelled();e.setCancelled(true);if(wasCancelled)return;if(!(e.getWhoClicked() instanceof Player p)||menus.get(p.getUniqueId())!=m||!valid(p,m)){e.getWhoClicked().closeInventory();return;}if(e.getRawSlot()<0||e.getRawSlot()>=54||!(e.getClick()==ClickType.LEFT||e.getClick()==ClickType.RIGHT))return;Consumer<Player> action=m.actions.get(e.getRawSlot());if(action==null||m.clickPending)return;m.clickPending=true;Bukkit.getScheduler().runTask(plugin,()->{m.clickPending=false;if(menus.get(p.getUniqueId())==m&&p.getOpenInventory().getTopInventory()==m.inventory&&valid(p,m))try{action.accept(p);}catch(RuntimeException ex){p.sendMessage("Dungeon action rejected: "+ex.getMessage());}});}
 @EventHandler(priority=EventPriority.HIGHEST) public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
 @EventHandler public void closed(InventoryCloseEvent e){if(e.getInventory().getHolder() instanceof Menu m)menus.remove(m.owner,m);}
 @EventHandler public void quit(PlayerQuitEvent e){menus.remove(e.getPlayer().getUniqueId());airLimiter.remove(e.getPlayer().getUniqueId());}
 @EventHandler public void worldChanged(PlayerChangedWorldEvent e){
  Menu m=menus.remove(e.getPlayer().getUniqueId());
  if(m!=null&&e.getPlayer().getOpenInventory().getTopInventory()==m.inventory)e.getPlayer().closeInventory();
 }
 /** Work limit: at most 16 menus per maintenance call. Click actions still validate immediately. */
 void refresh(){
  if(menus.isEmpty()){refreshCursor=0;return;}
  List<Menu> snapshot=new ArrayList<>(menus.values());
  GatewayWorkBudget.Window work=GatewayWorkBudget.next(snapshot.size(),refreshCursor,16);
  refreshCursor=work.next();cached=status();
  try{
   for(int i=0;i<work.count();i++){
    Menu m=snapshot.get((work.start()+i)%snapshot.size());
    Player p=Bukkit.getPlayer(m.owner);
    if(p==null||p.getOpenInventory().getTopInventory()!=m.inventory){menus.remove(m.owner,m);continue;}
    if(!valid(p,m)){p.closeInventory();continue;}
    if(m.screen==Screen.FLOORS||m.screen==Screen.SHARED||m.screen==Screen.PRIVATE_DETAIL||m.screen==Screen.PARTY)
     try{render(p,m);}catch(RuntimeException e){p.closeInventory();}
   }
  }finally{cached=null;}
 }
}
