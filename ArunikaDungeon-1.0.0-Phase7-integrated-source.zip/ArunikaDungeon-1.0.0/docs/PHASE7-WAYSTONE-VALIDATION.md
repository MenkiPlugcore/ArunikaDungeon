# Phase 7 — Waystone integrated candidate (source for 1.0.0)

## Provenance and preservation
This source begins with **ArunikaDungeon-1.0.0-source.zip** (official Work-produced canonical source, Library, Nov 21 2026). It is **not** the RC6 source. Phase 3 and 4 strict patches applied exactly. Phase 5 adapted to preserve the **GuiTheme.name/GuiTheme.lore** methods from Work, while adding bounded text and page chrome. Phase 6 strict patch applied. CdrWaystone and CdrWaystoneBedrock JAR files are not modified or bundled. Other core source and resources are unchanged apart from Phase7 test integration and this documentation.

## Key changes
- Phase 3: Bedrock air-tap ray/anchor fallback, fail-closed Floodgate player detection and dedicated UUID binding.
- Phase 4: Return Waystone/session/arena boundary checks and command-teleport protections.
- Phase 5: shared native GUI chroming, page indicator, empty-state prompts, text truncation preserving Work's GuiTheme palette.
- Phase 6: 350ms bounded per-player rate limiter, Floodgate reflection cache, 16-menu round-robin refresh, cleanup on quit/shutdown.

## Verification status
- Pure Java helper assertions: **66/66 PASS**, run against actual modified source with JDK21.
- Full Maven/Paper 1.21.11 compile and runtime: **NOT VERIFIED locally** (Maven and Paper dependency absent, DNS unavailable). The included GitHub Actions workflow can compile after uploading this source ZIP to GitHub.
- No player Java/Bedrock client runtime tests performed. Do not treat build success alone as proof of gameplay correctness.

## Real build
From the source root with Maven 3.9 and JDK 21:
`bash tools/build-verified.sh`
On success the verified JAR is at `target/verified/ArunikaDungeon-1.0.0.jar`, with SHA-256 files. Do not deploy the unverified candidate under `target/`.

## Staging acceptance
1. STOP server, backup both `plugins/ArunikaDungeon/` and server JARs. Use a staging server.
2. Keep `CdrWaystone 0.7.0` and `CdrWaystoneBedrock 0.2.0` untouched.
3. Check /adg status, /adg diagnostics, /adg gateway check; keep gateway disabled until UUIDs/arena config validated.
4. Java: click the real dedicated Waystone anchor, verify GUI and back buttons, 5 floors, Shared and Private, Return Waystone only in its own live session.
5. Bedrock phone: tap marker model and the anchor; test aimed empty-handed air tap; no effect in survival Waystone; test duplicate taps.
6. Test /home, /back, /tp, Ender Pearl/Chorus Fruit, Nusa Karsa teleport within/outside arenas and WorldGuard protections.
7. Test player quit/rejoin, world change, refresh, 17+ simultaneous GUI users; profile spark, measure TPS/MSPT/heap and compare against previous 1.0.0.
8. Only enable public gateway after all gates pass. Restore the previous verified JAR and matching data backup on failure.

## Known limitations
- Permission/gateway configuration is admin-controlled; no real binding UUID is included.
- Source code is integrated but a new JAR must be built and verified before installation.
- The previous official 1.0.0 JAR remains the safest rollback.
